﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using POSInventory.Models;

namespace POSInventory.Controllers
{
    public class SaleController : ApiController
    {
        POS_InventoryEntities1 db = new POS_InventoryEntities1();

        [HttpPost]
        public HttpResponseMessage Sale(Sales_Detail sale)
        {
            try
            {
                db.Sales_Detail.Add(sale);
                db.SaveChanges();
                return Request.CreateResponse(HttpStatusCode.OK, sale.Item_No);
            }catch(Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}
