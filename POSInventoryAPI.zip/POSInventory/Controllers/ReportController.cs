﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using POSInventory.Models;

namespace POSInventory.Controllers
{
    public class ReportController : ApiController
    {
        POS_InventoryEntities1 db = new POS_InventoryEntities1();

        [HttpGet]
        public HttpResponseMessage SearchSale(int sid)
        {
            try
            {
                var sl = db.Sales_Detail.Where(s => s.Sale_Id == sid).OrderBy(s => s.Sale_Id).ToArray();
                int price=0;
                int Saleid=0 ;
                int itms = 0;
                string cust="";
                for (int i=0; i<sl.Length; i++)
                {
                    price =price + sl[i].Price.Value;
                    Saleid =sl[i].Sale_Id;
                    itms = itms + 1;
                    cust = sl[i].Customer_Name.ToString();
                }
                string[] arr=new string[4];
                arr[0] = Saleid.ToString();
                arr[1] = itms.ToString();
                arr[2] = cust.ToString();
                arr[3] = price.ToString();
                return Request.CreateResponse(HttpStatusCode.OK, arr);
            }
            catch(Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        public HttpResponseMessage WholeSale()
        {
            try
            {
                var sl = db.Sales_Detail.OrderBy(s => s.Sale_Id).ToArray();
                int price = 0;
                int Saleid = 0;
                int itms = 0;
                string cust = "";
                for (int i = 0; i < sl.Length; i++)
                {
                    price = price + sl[i].Price.Value;
                    Saleid = sl[i].Sale_Id;
                    itms = itms + 1;
                    cust = sl[i].Customer_Name.ToString();
                }
                string[] arr = new string[2];
               // arr[0] = Saleid.ToString();
                arr[0] = itms.ToString();
               // arr[2] = cust.ToString();
                arr[1] = price.ToString();
                return Request.CreateResponse(HttpStatusCode.OK, arr);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}
