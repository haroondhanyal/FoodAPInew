﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using POSInventory.Models;

namespace POSInventory.Controllers
{
    public class StockController : ApiController
    {
        POS_InventoryEntities1 db = new POS_InventoryEntities1();

        [HttpGet]
        public HttpResponseMessage AllStockHistory()
        {
            try
            {
                var stock = db.Stocks.OrderBy(s => s.Stock_Date).ToList();
                return Request.CreateResponse(HttpStatusCode.OK, stock);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpPost]
        public HttpResponseMessage AddStock(Stock stock)
        {
            try
            {
                var x=db.Stocks.FirstOrDefault(xn=>xn.Item_No==stock.Item_No);
                if (x == null)
                {
                    db.Stocks.Add(stock);
                    db.SaveChanges();
                    var stocks = db.Stocks.FirstOrDefault(s => s.Stock_Id == stock.Stock_Id);
                    return Request.CreateResponse(HttpStatusCode.OK, stocks);
                }
                else
                {
                    x.Quantity = x.Quantity+stock.Quantity;
                    db.Entry(x).State = EntityState.Modified;
                    db.SaveChanges();
                    return Request.CreateResponse(HttpStatusCode.OK, x);
                }    
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }


        public class item
        {
            public int id { get; set; }
        }


        [HttpPost]
        public HttpResponseMessage SearchStockByItemNo(item id)
        {
            try
            {
                if (id.id != 0)
                {
                    var stock = db.Stocks.Where(s => s.Item_No == id.id).OrderBy(s => s.Stock_Date).ToList();
                    return Request.CreateResponse(HttpStatusCode.OK, stock);
                }
                else
                {
                    var stock = db.Stocks.OrderBy(s => s.Stock_Date).ToList();
                    return Request.CreateResponse(HttpStatusCode.OK, stock);
                }
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}
