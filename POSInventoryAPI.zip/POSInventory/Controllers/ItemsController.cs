﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using POSInventory.Models;

namespace POSInventory.Controllers
{
    public class ItemsController : ApiController
    {
        POS_InventoryEntities1 db = new POS_InventoryEntities1();

        [HttpGet]
        public HttpResponseMessage AllItems()
        {
            try
            {
                var Item = db.Items.OrderBy(i => i.Category).ToList();
                return Request.CreateResponse(HttpStatusCode.OK, Item);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpPost]
        public HttpResponseMessage AddItem(Item item)
        {
            try
            {
                var x = db.Items.Find(item.Item_No);
                if (x == null)
                {
                    db.Items.Add(item);
                    db.SaveChanges();

                    var Item = db.Items.FirstOrDefault(i => i.Item_No == item.Item_No);
                    return Request.CreateResponse(HttpStatusCode.OK, Item);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.Found, "Item already exist");
                }

                
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpPost]
        public HttpResponseMessage ModifyItem(Item item)
        {
            try
            {
                var origional = db.Items.Find(item.Item_No);
                if (origional == null)
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound, "Item not found");
                }

                db.Entry(origional).CurrentValues.SetValues(item);
                db.SaveChanges();

                return Request.CreateResponse(HttpStatusCode.OK, "Item is Modified");
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpGet]
        public HttpResponseMessage DeleteItem(int ItemNo)
        {
            try
            {
                var origional = db.Items.Find(ItemNo);
                if (origional == null)
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound, "Item not found");
                }


                db.Entry(origional).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();

                return Request.CreateResponse(HttpStatusCode.OK, "Item is Deleted");
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

     /*   [HttpPost]
        public HttpResponseMessage deductItem(Item item)
        {
            try
            {
                var origional = db.Items.Find(item.Item_No);
                if (origional == null)
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound, "Item not found");
                }

                origional.Quantity = item.Quantity;
                db.SaveChanges();

                return Request.CreateResponse(HttpStatusCode.OK, "Item is Modified");
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }*/

            public class item
        {
            public int ItemNo { get; set; }
        }

        [HttpPost]
        public HttpResponseMessage SearchItem(item ItemNo)
        {

            try
            {
                if (ItemNo.ItemNo != 0)
                {
                    var item = db.Items.Where(s => s.Item_No == ItemNo.ItemNo).ToList();
                    return Request.CreateResponse(HttpStatusCode.OK, item);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.OK, "Please Enter itemno");
                }
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }

        }
    }
}
